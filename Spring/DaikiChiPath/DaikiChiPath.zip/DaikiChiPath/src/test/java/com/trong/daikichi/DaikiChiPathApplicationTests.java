package com.trong.daikichi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikiChiPathApplicationTests {

	@Test
	void contextLoads() {
	}

}
